from django.shortcuts import render

context={'name':'Amir homayoun','last_name':'Salehi','age':15}

def home(request):
    return render(request,'web/index.html',context)
def contact(request):
    return render(request,'web/contact.html')
def services(request):
    return render(request,'web/services.html')
