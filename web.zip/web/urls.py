from django.urls import path,include
from web.views import *
from django.conf import settings
from django.conf.urls.static import static
app_name='web'

urlpatterns = [
    path('', home,name='home'),
    path('home/', home,name='home'),
    path('main/', home,name='home'),
    path('about/', home,name='about'),

    path('contact/', contact,name='contact'),
    path('services/', services,name='services')
]


urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)