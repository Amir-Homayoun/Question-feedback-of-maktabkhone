from django.shortcuts import render,redirect

# Create your views here.

from account.forms import SignUp_form
from django.urls import reverse
from django.http import HttpResponseRedirect
def signup_view(request):
    if request.method=='POST':
        form = SignUp_form(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse('login'))

    form=SignUp_form()
    return render(request, 'account/signup.html',{'form':form})

from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import AuthenticationForm

# def login_view(request):
#     if not request.user.is_authenticated:
#         if request.method == 'POST':
#             form=AuthenticationForm(request=request,data=request.POST)
#             # if form.is_valid():
#             email=form.data.get('email')
#             print(email)
#             password=form.data.get('password')
#             user = authenticate(request, username=email,password=password)
#             if user is not None:
#                 login(request, user)
#                 return redirect('/')  # Redirect to a success page.
#
#         form=AuthenticationForm()
#         return render(request, 'account/login.html',{'form':form})
#     else:
#         return redirect('/')

