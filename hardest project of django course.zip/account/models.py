from django.db import models

# Create your models here.

from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager, UserManager


# class CustomeUserManager(BaseUserManager):
#     def _create_user(self, email, password,first_name,last_name,mobile, **extra_fields):
#         if not email:
#             raise ValueError('Email must be set')
#         if not password:
#             raise ValueError('Password must be set')
#         user = self.model(
#             email=self.normalize_email(email),
#             first_name=first_name,
#             last_name=last_name,
#             mobile=mobile,
#             **extra_fields)
#         user.set_password(password)
#         user.save(using=self._db)
#         return user
#
#     def create_user(self, email, password, first_name, last_name, mobile, * "extra_fields):
#
#
# class Sign_in(AbstractBaseUser,PermissionsMixin,BaseUserManager):
#     email = models.EmailField(db_index=True,unique=True,max_length=254)
#     first_name = models.CharField(max_length=240)
#     last_name = models.CharField(max_length=255)
#
#     mobile=models.CharField(max_length=50)
#     address=models.CharField(max_length=250)
#
#     is_staff = models.BooleanField(default=True)
#     is_active = models.BooleanField(default=True)
#     is_superuser = models.BooleanField(default=False)
#
#     objects=CustomeUserManager()
#
#     USERNAME_FIELD = 'email'
#     REQUIRED_FIELDS = ['first_name', 'last_name', 'mobile']
#
#     class Meta:
#         verbose_name = 'User'
#         verbose_name_plural = 'Users'