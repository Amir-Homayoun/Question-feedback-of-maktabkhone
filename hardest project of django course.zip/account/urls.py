from django.urls import path,include
from .views import *
from django.contrib.auth import views as auth_views


app_name='account'

urlpatterns=[

    path('signup/',signup_view,name='signup'),# signup
    # path('signin/',login_view,name='login'),# signin
    # path('forget_password/',forget_view,name='forget_password'),# forget password

]