from django import template
from django.utils import timezone
from blog.models import Post

register=template.Library()


@register.inclusion_tag('inclusion_tags_template/6_latest_post.html',name='latest_6posts_home')
def latest_post():
    post=Post.objects.filter(published_date__lt=timezone.now(),status='1').order_by('-published_date')[:6]
    contex={'posts': post}
    return contex
