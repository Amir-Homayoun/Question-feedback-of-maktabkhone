from django.shortcuts import render

from django.http import HttpResponse,HttpResponseRedirect

def home(request):
    return render(request,'websitee/index.html')

# ========================================================
from websitee.forms import ContactForm
from django.contrib import messages
def contact(request):
    if request.method=='POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,'compliment submitted successfully')
            messages.success(request,'compliment submitted successfully')
        else:
            messages.success(request,"compliment didn't submit successfully")
            messages.success(request,"compliment didn't submit successfully")

    form=ContactForm()
    return render(request,'websitee/contact.html',{'form':form})
# ========================================================

from websitee.forms import NewsletterForm
def newsletter(request):
    if request.method=='POST':
        print('ok')
        form=NewsletterForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/')
        else:
            return HttpResponseRedirect('/')



def about(request):
    return render(request,'websitee/about.html')


def test(request):
    form_data=ContactForm(request.POST)
    if form_data.is_valid():
        form_data.save()
    form=ContactForm()
    return render(request,'websitee/test.html',{'form':form})




