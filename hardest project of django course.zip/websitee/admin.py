from django.contrib import admin
from websitee.models import Contact,Newsletter
# Register your models here.

@admin.register(Contact)
class ContactAdmin(admin.ModelAdmin):
    date_hierarchy = 'created_date'
    list_display = ('name','subject','created_date','updated_date')
    empty_value_display='-empty-'
    list_filter = ('name','email')
    ordering = ('created_date',)

# ================================================================
@admin.register(Newsletter)
class NewsletterAdmin(admin.ModelAdmin):
    list_display = ['email','created_date']
    date_hierarchy = 'created_date'
# ================================================================
