from django.apps import AppConfig


class WebsiteeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'websitee'
