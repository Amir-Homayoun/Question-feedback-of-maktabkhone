from django.db import models

from django.contrib.auth.models import User

# Create your models here.
class Category(models.Model):
    name=models.CharField(max_length=225)

    def __str__(self):
        return self.name

from django.urls import reverse
from taggit.managers import TaggableManager
class Post(models.Model):
    image =models.ImageField(upload_to='blog_image/',default='/blog_image/default.jpg')
    author =models.ForeignKey(User,on_delete=models.SET_NULL,null=True)
    title = models.CharField(max_length=255)
    content = models.TextField()
    tags =TaggableManager()
    category =models.ManyToManyField(Category)
    counted_views = models.IntegerField(default=0)
    status = models.BooleanField(default=False)
    login_required = models.BooleanField(default=False)
    published_date = models.DateTimeField(blank=True,null=True)
    created_date = models.DateTimeField(auto_now_add=True)
    updated_date = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.title} - {self.id}"

    class Meta:
        ordering = ('-status',)
        verbose_name='پست'
        verbose_name_plural='پست ها'

    def get_absolute_url(self):
        return reverse('blog:single_post',kwargs={'pid':self.id})


class Comment(models.Model):
    post=models.ForeignKey(Post,on_delete=models.CASCADE)
    name=models.CharField(max_length=225)
    email=models.EmailField()
    subject=models.CharField(max_length=225)
    message=models.TextField()
    # ================================
    approved=models.BooleanField(default=True)
    # ================================
    created_date=models.DateTimeField(auto_now_add=True)
    updated_date=models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.id} - {self.name}"

