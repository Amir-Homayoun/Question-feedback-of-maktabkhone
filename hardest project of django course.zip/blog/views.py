from django.shortcuts import render,get_object_or_404
from blog.models import Post
from django.utils import timezone
# from django.core.paginator import Paginator


from django.core.paginator import Paginator,EmptyPage,PageNotAnInteger

def blog_home(request,**kwargs):
    posts = Post.objects.filter(published_date__lt=timezone.now(),status=1)
    if kwargs.get('cat'):
        posts=posts.filter(category__name=kwargs['cat'])
    if kwargs.get('username'):
        posts=posts.filter(author__username=kwargs['username'])
    if kwargs.get('tag'):
        posts=posts.filter(tags__name=kwargs['tag'])


    posts=Paginator(posts,2)
    print(posts.page_range)
    page_number = request.GET.get('page')

    try:
        posts=posts.page(page_number)
        print('hello')

    except PageNotAnInteger:
        posts=posts.page(1)
    except EmptyPage:
        # posts=posts.get_page(Paginator.num_pages)
        # posts=posts.page(1)
        from django.http import Http404
        raise Http404(f"Page {page_number} not found")

    context = {'posts': posts}
    return render(request,'blog/blog-home.html',context)




# ================================================================
from blog.models import Comment
from blog.forms import CommentForm
from django.contrib import messages
from django.urls import reverse
from django.http import HttpResponseRedirect

def single_post(request,pid):
    # post=Post.objects.get(id=pid)
    selected_post=get_object_or_404(Post,pk=pid,published_date__lt=timezone.now(),status=1)

    def view_process():
        comments=Comment.objects.filter(post=pid,approved=True).order_by('-created_date')
        print(comments)

        # previous and next
        all_objects = Post.objects.filter(published_date__lt=timezone.now(),status=1)
        index=list(all_objects).index(selected_post)
        len_post=len(list(all_objects))

        previous_post=list(all_objects)[index-1]

        try:
            next_post = list(all_objects)[index + 1]
        except IndexError:
            next_post=None

        def next_post_id():
            if next_post != None:
                return next_post.id
            else:
                return None

        form = CommentForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'compliment submitted successfully')
            # messages.success(request, 'comment submitted successfully')
        else:
            # messages.success(request, "compliment didn't submit successfully")
            messages.success(request, "comment didn't submit successfully")
        form=CommentForm()
        contex={'selected_post':selected_post,


                'previous_post':previous_post,
                'previous_post_index':index-1,
                'previous_post_id':previous_post.id,

                'next_post':next_post,
                'next_post_index':index+1,
                'next_post_id':next_post_id(),


                'index_len_post':len_post-1,
                'all_objects':all_objects,

                'comments':comments,
                'form':form,}
        return render(request,'blog/blog-single.html',contex)


    if selected_post.login_required==False:
        return view_process()
    else:
        if request.user.is_authenticated:
            return view_process()
        # else:
            # return HttpResponseRedirect(reverse('account:login'))
# ================================================================

def blog_search(request):
    posts = Post.objects.filter(published_date__lt=timezone.now(),status=1)
    if request.method =='GET':
        if s:= request.GET.get('s'):
            posts=posts.filter(content__contains=s)
    context = {'posts': posts}
    return render(request,'blog/blog-home.html',context)




def test(request):
    post=Post.objects.all()
    context={'posts':post}
    return render(request,'blog/test.html',context)