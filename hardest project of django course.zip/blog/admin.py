from django.contrib import admin

# Register your models here.

from blog.models import Post,Category
# admin.site.register(Post)
admin.site.register(Category)

from django_summernote.admin import SummernoteModelAdmin
@admin.register(Post)
class PostAdmin(SummernoteModelAdmin):
    date_hierarchy = 'created_date'
    empty_value_display ='-empty-'
    # fields = ('title','content')
    # exclude = ('counted_views',)
    list_display = ['id',"title",'author','counted_views','status','login_required','published_date','created_date']
    # list_filter = ('published_date','status')
    search_fields = ['title','content']
    summernote_fields = ('content',)

# =======================================
from blog.models import Comment
@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    date_hierarchy = 'created_date'
    list_display = ['post','approved','created_date']


# ================================






