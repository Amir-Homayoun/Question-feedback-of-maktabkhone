from django import template
from django.utils import timezone

register=template.Library()

from blog.models import Post,Category

@register.simple_tag
def increase_views(pid):
    post=Post.objects.get(id=pid)
    post.counted_views+=1
    post.save()
    return post.counted_views

@register.inclusion_tag('blog/common_codes/latest_post.html')
def latest_post():
    post=Post.objects.filter(published_date__lt=timezone.now(),status='1').order_by('-published_date')[:4]
    contex={'posts': post}
    return contex

@register.inclusion_tag('blog/common_codes/post_category.html')
def category_handler():
    posts=Post.objects.filter(published_date__lt=timezone.now(),status=1)
    categories=Category.objects.all()

    dic_category={}
    for name in categories:
        dic_category[name]=posts.filter(category=name).count()

    contex={'category':dic_category}
    return contex
@register.inclusion_tag('blog/common_codes/tag_cloud.html')
def tag_clouds(pid):
    posts=Post.objects.get(id=pid)

    return {'posts':posts}


# ================================================================
from blog.models import Comment
@register.simple_tag()
def comment_count(pid):
    return Comment.objects.filter(post=pid,approved=True).count()
# =====================================================================