from django import template
register=template.Library()


@register.simple_tag
def func_without_argument():
    return 'hello'

@register.simple_tag
def func_with_2_argument(a,b):
    return a+b

@register.simple_tag(name='multiple')
def func_multiple(a,b):
    return a*b

from blog.models import Post
# @register.simple_tag(name='total_post')
# def all_post():
#     all_post=Post.objects.all().count()
#     return all_post

@register.simple_tag(name='total_post')
def all_post():
    all_post=Post.objects.all()
    return all_post

@register.simple_tag(name='title_name')
def tiltle(obj):
    return obj.title

@register.filter
def snippet(value,index):
    index = index.split(',')
    if len(index)==1:
        index = [int(index[0]),1]

    if len(value)-1<=index[0]:
        return value[:index[0]:index[1]]
    else:
        return value[:index[0]:index[1]]+'...'

@register.inclusion_tag('inclusion_tags_template/latest_post_test.html')
def latest_posts(value):
    posts=Post.objects.filter(status='1').order_by('-published_date')
    contex={'posts': posts}
    return contex