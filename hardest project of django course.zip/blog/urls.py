from blog.feeds import LatestEntriesFeed
from django.urls import path

from blog.views import *


app_name='blog'

urlpatterns = [
    path('',blog_home,name='blog-home'),
    # path('single/',blog_single,name='blog-single'),
    path('test/',test,name='test'),
    path('<int:pid>/',single_post,name='single_post'),
    path('category/<str:cat>',blog_home,name='category'),
    path('author/<str:author_username>', blog_home, name='author'),
    path('search/', blog_search, name='search'),
    path('tag/<str:tag>', blog_home, name='tag'),
    path("rss/feed/", LatestEntriesFeed()),

]
