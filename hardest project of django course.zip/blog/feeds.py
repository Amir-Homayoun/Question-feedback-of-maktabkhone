from django.contrib.syndication.views import Feed
from django.urls import reverse
from blog.models import Post
from django.utils import timezone


class LatestEntriesFeed(Feed):
    title = "Blog newest posts"
    link = "rss/feed"
    description = "Best blog ever"

    def items(self):
        post=Post.objects.filter(published_date__lt=timezone.now(),status=1)
        return Post.objects.order_by("-published_date")[:5]

    def item_title(self, item):
        return item.title

    def item_description(self, item):
        return ''.join(item.content.strip()[:100])

    # item_link is only needed if NewsItem has no get_absolute_url method.
    # def item_link(self, item):
    #     return reverse("news-item", args=[item.pk])